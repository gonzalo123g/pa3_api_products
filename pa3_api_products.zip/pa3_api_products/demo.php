<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body class="p-4">

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">
                        Actualización de Producto
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6 id="idActualizar" class="text-center text-muted"></h6>
                    <form id="modalForm" class="d-flex flex-column gap-3 mt-3">
                        <input type="text" id="nomActualizar" name="nombre" class="form-control"
                            placeholder="Nombre del producto" />
                        <input type="number" id="precioActualizar" name="precio" class="form-control"
                            placeholder="Precio" />
                        <input type="number" id="stockActualizar" name="stock" class="form-control"
                            placeholder="Stock" />
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">
                        Cancelar
                    </button>
                    <button onclick="ActualizarDatos()" type="button" class="btn btn-primary">
                        Actualizar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Contenedor para el formulario -->
    <div class="mb-4">
        <h1 class="h3 mb-3">Productos</h1>

        <form id="miFormulario" class="d-flex gap-2">
            <input type="text" name="nombre" class="form-control" placeholder="Nombre" required>
            <input type="text" name="precio" class="form-control" placeholder="Precio" required>
            <input type="number" name="stock" class="form-control" placeholder="Stock" required>
            <button type="submit" class="btn btn-primary">Crear</button>
        </form>
    </div>

    <div class="table-responsive">
        <table id="miTabla" class="table table-hover align-middle"></table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const idActualizar = document.getElementById("idActualizar");
            const nomActualizar = document.getElementById("nomActualizar");
            const precioActualizar = document.getElementById("precioActualizar");
            const stockActualizar = document.getElementById("stockActualizar");

            const miTabla = document.getElementById("miTabla");
            const miFormulario = document.getElementById("miFormulario");

            const MyFetch = async (url) => {
                try {
                    const respuesta = await fetch(url);
                    if (!respuesta.ok) {
                        alert("Error de Conexión");
                        return null;
                    }
                    return await respuesta.json();
                } catch (e) {
                    console.log("Error:", e);
                    return null;
                }
            };

            const MostrarDatos = async () => {
                const datos = await MyFetch("http://localhost:8000/api/products");
                if (!datos) return;

                miTabla.replaceChildren();
                
                let miElementoDatbla = ` 
                    <thead class="text-secondary border-bottom">
                        <tr>
                            <th scope="col" class="text-center py-3">ID</th>
                            <th scope="col" class="py-3">Nombre</th>
                            <th scope="col" class="py-3">Precio</th>
                            <th scope="col" class="py-3">Stock</th>
                            <th scope="col" class="text-end py-3 pe-4" colspan="2">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>`;

                datos.forEach((e) => {
                    miElementoDatbla += `
                        <tr>
                            <th data-id="${e.id}" scope="row" class="text-center text-muted fw-normal">${e.id}</th>
                            <td class="fw-semibold">${e.nombre}</td>
                            <td>$${e.precio}</td>
                            <td>${e.stock}</td>
                            <td class="text-end pe-1" style="width: 1%;">
                                <button
                                    onclick="ModalActualizarId(this)"
                                    type="button"
                                    class="btn btn-link btn-sm text-decoration-none"
                                    data-bs-toggle="modal"
                                    data-bs-target="#exampleModalCenter">
                                    Editar
                                </button>
                            </td>
                            <td class="text-end pe-3" style="width: 1%;">
                                <button class="btn btn-link btn-sm text-danger text-decoration-none" onclick="EliminarDatos(this)">Eliminar</button>
                            </td>
                        </tr>`;
                });

                miElementoDatbla += `</tbody>`;
                miTabla.insertAdjacentHTML("beforeend", miElementoDatbla);
            };

            MostrarDatos();

            window.ModalActualizarId = function(button) {
                const tr = button.closest("tr");
                const id = tr.children[0].dataset.id;
                idActualizar.textContent = `ID Producto: ${id}`;
                idActualizar.dataset.id = id;
                nomActualizar.value = tr.children[1].textContent;
                precioActualizar.value = tr.children[2].textContent.replace('$', '');
                stockActualizar.value = tr.children[3].textContent;
            };

            window.ActualizarDatos = async function() {
                const id = idActualizar.dataset.id;
                if (!id) return;

                const datosActualizados = {
                    nombre: nomActualizar.value,
                    precio: parseFloat(precioActualizar.value),
                    stock: parseInt(stockActualizar.value)
                };

                try {
                    const respuesta = await fetch(`http://localhost:8000/api/products/${id}`, {
                        method: "PUT",
                        headers: { "Content-type": "application/json" },
                        body: JSON.stringify(datosActualizados),
                    });

                    if (!respuesta.ok) {
                        alert("Error en la petición");
                        return;
                    }

                    const modalEl = document.getElementById('exampleModalCenter');
                    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                    modal.hide();

                    MostrarDatos();
                } catch (e) {
                    console.log("Error:", e);
                }
            };

            window.EliminarDatos = async function(e) {
                try {
                    const id = e.closest("tr").children[0].dataset.id;
                    const respuesta = await fetch(`http://localhost:8000/api/products/${id}`, {
                        method: "DELETE",
                    });

                    if (!respuesta.ok) {
                        alert("Error en la petición");
                        return;
                    }
                    MostrarDatos();
                } catch (e) {
                    console.log("Error:", e);
                }
            };

            miFormulario.addEventListener("submit", async (e) => {
                e.preventDefault();
                try {
                    const formData = new FormData(miFormulario);
                    const datos = Object.fromEntries(formData);

                    const respuesta = await fetch("http://localhost:8000/api/products/register", {
                        method: "POST",
                        headers: { "Content-type": "application/json" },
                        body: JSON.stringify(datos),
                    });

                    if (!respuesta.ok) {
                        alert("Error en la petición");
                        return;
                    }
                    miFormulario.reset();
                    MostrarDatos();
                } catch (e) {
                    console.log("Error:", e);
                }
            });
        });
    </script>
</body>

</html>